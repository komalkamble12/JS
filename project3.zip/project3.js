var quotes=['YOU ARE THE DECORATER OF YOUR SKY','I NEVER LOSE EITHER I WIN OR I LEARN','SET LIMITS , NOT EVERYONE IS WORTHY','EVERY NEXT LEVEL OF YOUR LIFE WILL DEMAND A DIFFERENT YOU','YOUR JOURNEY BELONGS TO YOU']

function newquote()
{
    var randomNumber = Math.floor(Math.random()* (quotes.length));
    document.getElementById('quote').innerHTML=quotes[randomNumber];
}

