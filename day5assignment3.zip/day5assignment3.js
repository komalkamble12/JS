
//promises

const todos = [];
function gettodos()
{
    let status = new Promise((resolve,reject) => {
        setTimeout(() => {
            todos.push('avatar');
            resolve('get');
        },3000)
    })

    let result =status;
    console.log(result);
}

gettodos();

//async await


const todoss = [];
async function gettodoss()
{
    let status = new Promise((resolve,reject) => {
        setTimeout(() => {
            todos.push('avatar');
            resolve('get');
        },3000)
    })

    let result =await status;
    console.log(result.length);
}

gettodoss();

//Fetch API

//making a get request

fetch('https://jsonplaceholder.typicode.com/todos')
.then(response =>response.json())
.then(data => console.log(data))