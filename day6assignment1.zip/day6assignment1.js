// to iterate over an array of colours

let colours=['red','purple','pink','black','orange','white'];
const list = document.querySelector('#list');
console.log(list);

colours.forEach(colour=>{
    list.innerHTML+=`<li>${colour}</li>`;
})

//to change the background color

const pg = document.getElementById('page');
console.log(pg.getAttribute('id'));

//setting time interval of 5 seconds
  
function f()
{            
pg.setAttribute('style','background-color:yellow;')
}
// setInterval(,5000)

